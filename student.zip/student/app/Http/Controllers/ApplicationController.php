<?php

namespace App\Http\Controllers;

use App\Project;
use Illuminate\Http\Request;

class ApplicationController extends Controller
{

    public function index()
    {

        return view('home');
    }

    public function show()
    {
        $datas = Project::orderBy('id', 'DESC')->get();
        return view('show-reports', compact('datas'));
    }

    public function add(Request $request)
    {
        if ($request->isMethod('get')) {
            return redirect()->back();
        }


        if ($request->isMethod('post')) {
            $boj = new Project();

            $boj->filed_date = $request->filed_date;
            $boj->employee_id = $request->employee_id;
            $boj->leave_type = $request->leave_type;
            $boj->effective_date = $request->effective_date;
            $boj->due_date = $request->due_date;
            $boj->reason = $request->reason;

            if ($request->hasFile('upload')) {
                $file = $request->file('upload');
                $ext = $file->getClientOriginalExtension();
                $imageName = md5(microtime()) . '.' . $ext;
                $uploadPath = public_path('file/');
                if ($file->move($uploadPath, $imageName)) {
                    $boj->file = $imageName;
                }


            }

            if ($boj->save()) {
                return redirect()->route('show-report')->with('success', 'Information was successfully added');
            }


        }
    }

    public function deleteWithFile($id)
    {
        $findData = Project::findOrFail($id);
        $fineName = $findData->file;
        $deletePath = public_path('file/' . $fineName);
        if (file_exists($deletePath) && is_file($deletePath)) {
            return unlink($deletePath);
        }

        return true;
    }


    public function delete(Request $request)
    {
        $id = $request->criteria;
        if ($this->deleteWithFile($id) && Project::findOrFail($id)->delete()) {
            return redirect()->route('show-report')->with('success', 'Information was deleted');

        }
    }


    public function edit(Request $request)
    {
        $id = $request->criteria;
        $data = Project::findORFail($id);
        return view('edit-report', compact('data'));

    }

    public function editAction(Request $request)
    {
        if ($request->isMethod('get')) {
            return redirect()->back();
        }


        if ($request->isMethod('post')) {
            $id = $request->criteria;
            $boj = Project::findOrFail($id);

            $boj->filed_date = $request->filed_date;
            $boj->employee_id = $request->employee_id;
            $boj->leave_type = $request->leave_type;
            $boj->effective_date = $request->effective_date;
            $boj->due_date = $request->due_date;
            $boj->reason = $request->reason;

            if ($request->hasFile('upload')) {
                $file = $request->file('upload');
                $ext = $file->getClientOriginalExtension();
                $imageName = md5(microtime()) . '.' . $ext;
                $uploadPath = public_path('file/');
                if ($this->deleteWithFile($id) && $file->move($uploadPath, $imageName)) {
                    $boj->file = $imageName;
                }


            }

            if ($boj->update()) {
                return redirect()->route('show-report')->with('success', 'Information was successfully updated');
            }


        }
    }

}
