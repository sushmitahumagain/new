<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{

    protected $fillable =
        [
            'filed_date',
            'employee_id', 'leave_type',
            'effective_date',
            'due_date',
            'reason',
            'file'

        ];
}
